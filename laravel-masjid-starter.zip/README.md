# Masjid QR Absensi — Laravel Starter (Gitpod-ready)

Open in Gitpod after pushing to GitHub.