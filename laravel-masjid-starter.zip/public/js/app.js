// minimal js
